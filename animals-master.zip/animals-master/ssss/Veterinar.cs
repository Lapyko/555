﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ssss;

namespace ssss
{
    internal class Veterinar
    {
        void treatAnimal(Animal animal)
        {
            Console.WriteLine("еда: " + animal.food + "; местоположение " + " " + animal.location);

        }
     }
}
